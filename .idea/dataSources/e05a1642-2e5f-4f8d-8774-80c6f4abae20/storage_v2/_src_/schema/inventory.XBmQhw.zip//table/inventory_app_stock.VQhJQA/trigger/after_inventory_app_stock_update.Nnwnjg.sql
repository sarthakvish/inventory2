create definer = sarthak@`%` trigger after_inventory_app_stock_update
    after update
    on inventory_app_stock
    for each row
BEGIN
	IF new.issue_quantity = 0 
		THEN INSERT INTO inventory_app_stockhistory(
			id, 
            auth_user_id,
			last_updated, 
			category, 
			item_name,
            issue_quantity,
            issue_to,
            issue_by,
			quantity, 
			receive_quantity, 
			receive_by) 
		VALUES(
			new.id, 
            new.auth_user_id,
			new.last_updated, 
			new.category,
			new.item_name,
            new.issue_quantity,
            new.issue_to,
            new.issue_by,
			new.quantity, 
			new.receive_quantity, 
			new.receive_by);

	ELSEIF new.receive_quantity = 0 
		THEN INSERT INTO inventory_app_stockhistory(
			id, 
            auth_user_id,
			last_updated, 
			category,
			item_name,
            receive_quantity,
           --  receive_by,
			issue_quantity, 
			issue_to, 
			issue_by,
			quantity) 
		VALUES(
			new.id, 
            new.auth_user_id,
			new.last_updated, 
			new.category,
			new.item_name,
            new.receive_quantity,
           --  new.receive_by,
			new.issue_quantity, 
			new.issue_to, 
			new.issue_by, 
			new.quantity);
	END IF;
END;

